import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Paleta derivada diretamente das embalagens Futi
        "futi-yellow": "#FFD400", // amarelo canarinho da caixa Futi Collection
        "futi-yellow-deep": "#F2B705",
        "futi-green": "#0F7B3E", // verde do logo "futi" e detalhes do uniforme
        "futi-navy": "#0B1E3D", // azul da caixa Futi Arena
        "futi-navy-deep": "#071429",
        "pitch": "#123018", // verde profundo de gramado, usado em fundos escuros
        "biscoito": "#FFF6E3", // tom creme de biscoito, fundo claro da página
        "gold-trophy": "#C9A227", // dourado do troféu na imagem do Futi Arena
        "ink": "#181510",
      },
      fontFamily: {
        display: ["var(--font-fredoka)"],
        body: ["var(--font-manrope)"],
        mono: ["var(--font-space-mono)"],
      },
      backgroundImage: {
        "grain": "radial-gradient(circle at 1px 1px, rgba(0,0,0,0.06) 1px, transparent 0)",
      },
      keyframes: {
        pulseSoft: {
          "0%, 100%": { transform: "scale(1)", opacity: "1" },
          "50%": { transform: "scale(1.08)", opacity: "0.85" },
        },
        floatUp: {
          "0%": { transform: "translateY(12px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
      },
      animation: {
        pulseSoft: "pulseSoft 2.4s ease-in-out infinite",
        floatUp: "floatUp 0.8s ease-out forwards",
      },
    },
  },
  plugins: [],
};

export default config;
