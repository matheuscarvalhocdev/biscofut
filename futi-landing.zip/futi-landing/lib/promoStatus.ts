/**
 * Status da promoção — o "interruptor mestre" definido no planejamento do
 * projeto Futi.
 *
 * Em produção, este valor NUNCA deve ser controlado pelo cliente (front-end).
 * Ele precisa vir de uma fonte confiável no backend (ex.: flag no banco,
 * atualizada manualmente pelo time responsável assim que o número do CA for
 * registrado), e cada rota/endpoint transacional deve validar esse status no
 * servidor — não só esconder o botão na tela.
 *
 * - DRAFT       -> nada no ar ainda.
 * - PRE_LAUNCH  -> landing institucional no ar, zero funcionalidade
 *                  transacional (sem cadastro, sem nota fiscal, sem número).
 * - ACTIVE      -> CA emitido e registrado: cadastro, envio de nota e
 *                  geração de números da sorte liberados.
 */
export type PromoStatus = "DRAFT" | "PRE_LAUNCH" | "ACTIVE";

// Enquanto o CA não é emitido, isto deve permanecer "PRE_LAUNCH".
export const PROMO_STATUS: PromoStatus = "PRE_LAUNCH";
