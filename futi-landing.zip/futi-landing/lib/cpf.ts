/**
 * Validação de CPF — apenas o cálculo padrão de dígito verificador.
 * Roda inteiramente no navegador, não envia nada para nenhum servidor.
 * Serve para dar feedback imediato no formulário; a validação de verdade
 * (CPF existente, ativo na Receita etc.) é responsabilidade do backend.
 */
export function formatCPF(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  return digits
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

export function isValidCPF(value: string): boolean {
  const cpf = value.replace(/\D/g, "");
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;

  const calcCheckDigit = (base: string, factor: number) => {
    let total = 0;
    for (const digit of base) {
      total += parseInt(digit, 10) * factor--;
    }
    const remainder = (total * 10) % 11;
    return remainder === 10 ? 0 : remainder;
  };

  const d1 = calcCheckDigit(cpf.slice(0, 9), 10);
  const d2 = calcCheckDigit(cpf.slice(0, 10), 11);

  return d1 === parseInt(cpf[9], 10) && d2 === parseInt(cpf[10], 10);
}
