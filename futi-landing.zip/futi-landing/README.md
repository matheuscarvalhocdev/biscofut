# Futi — Landing Page da Promoção

Landing page da promoção comercial **Futi**, parceria **Biscoitê × Neymar
Jr.** Traz mecânica de participação, produtos elegíveis, prêmios, cadastro
do participante, regulamento e dúvidas frequentes — no estilo das páginas de
promoção comercial mais comuns no mercado brasileiro (ex.: Eu Quero Nestlé).

## ⚠️ Importante — status regulatório (fase pré-CA)

Esta promoção ainda **não tem o Certificado de Autorização (CA)** emitido
pela SPA/Ministério da Fazenda. Por isso:

- O arquivo [`lib/promoStatus.ts`](./lib/promoStatus.ts) define o status da
  promoção (`PRE_LAUNCH` por padrão). Esse é o "interruptor mestre": em
  produção, nenhuma funcionalidade transacional (cadastro, nota fiscal,
  número da sorte) pode ficar acessível enquanto ele não virar `ACTIVE`.
- **Esse valor não pode ser controlado pelo front-end em produção.** Aqui
  ele existe só para a demonstração local. Quando o backend for construído,
  cada endpoint transacional precisa validar o status no servidor.
- Para você revisar os dois estados da página, a seção "Participe" tem um
  alternador de **prévia** (Antes do CA / Depois do CA) — ele é só uma
  ferramenta de demonstração visual e deve ser removido quando a integração
  real for feita.
- O cadastro, login e a "prévia da área do participante" são **protótipos de
  front-end**: nenhum dado é enviado a um servidor. Os comentários no código
  (`RegistrationArea.tsx`) marcam onde entra a integração real.

## ⚠️ Conteúdo de exemplo

Prêmios, pesos de números por produto (P1/P2/P3), datas de vigência e o
texto do regulamento estão marcados como **exemplo** — dependem de decisões
do time de negócio e jurídico antes do lançamento. Procure por `[a definir]`
e pelos avisos "conteúdo de exemplo" no código.

## Stack

- [Next.js 14](https://nextjs.org/) (App Router) + TypeScript
- [Tailwind CSS](https://tailwindcss.com/)
- Fontes auto-hospedadas via [Fontsource](https://fontsource.org/): Fredoka
  (display), Manrope (texto), Space Mono (specs/detalhes)

## Como rodar localmente (VSCode)

Pré-requisito: [Node.js](https://nodejs.org/) 18.18 ou superior.

```bash
npm install
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000).

## Estrutura do projeto

```
futi-landing/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── components/
│   ├── Header.tsx
│   ├── Hero.tsx                 # abertura + storytelling da parceria
│   ├── HowItWorks.tsx           # mecânica em 3 passos
│   ├── EligibleProducts.tsx     # produtos participantes (P1/P2/P3)
│   ├── FiguresBanner.tsx        # banner atmosférico
│   ├── Prizes.tsx               # prêmios (conteúdo de exemplo)
│   ├── RegistrationArea.tsx     # cadastro/login + gate de status + prévia da área logada
│   ├── Regulation.tsx           # resumo do regulamento + compliance
│   ├── FAQ.tsx                  # dúvidas frequentes (accordion)
│   └── Footer.tsx
├── lib/
│   ├── promoStatus.ts           # o "interruptor mestre" do CA
│   └── cpf.ts                   # validação de CPF (só no navegador)
├── public/images/                # imagens de produto/campanha fornecidas
└── tailwind.config.ts            # paleta e tipografia da marca Futi
```

## Conceito de design

- **Paleta**: amarelo canarinho (`#FFD400`) e verde (`#0F7B3E`) da caixa
  Futi Collection; azul-marinho (`#0B1E3D`) da caixa Futi Arena; dourado de
  troféu (`#C9A227`); creme de biscoito (`#FFF6E3`).
- **Tipografia**: Fredoka (títulos, arredondada, energia de brinquedo),
  Manrope (leitura), Space Mono (specs, imitando a ficha técnica da caixa).
- **Assinatura visual**: produtos e prêmios usam a moldura pontilhada
  "carta colecionável" (Carta Nº 01, 02...), reforçando o conceito de blind
  box. A mecânica ("Como participar") usa numeração de passos simples — é
  processo, não colecionável — para não misturar as duas linguagens.

## Próximos passos sugeridos

1. Resolver as decisões pendentes de negócio/jurídico (prêmios, pesos por
   produto, datas, regulamento completo).
2. Confirmar status do CA junto à SPA — só então trocar `PROMO_STATUS` para
   `ACTIVE` **no backend**.
3. Construir a API de cadastro, validação de nota fiscal (NFC-e/NF-e) e
   geração de números da sorte, sempre validando o status da promoção no
   servidor.
4. Substituir os campos de login/cadastro de demonstração pela integração
   real (autenticação, persistência em banco).
5. Adicionar o PDF do regulamento assim que aprovado, e remover o
   `disabled` do botão em `Regulation.tsx`.
