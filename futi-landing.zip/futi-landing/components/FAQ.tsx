"use client";

import { useState } from "react";

const faqs = [
  {
    q: "Quem pode participar da promoção Futi?",
    a: "Pessoas físicas maiores de 18 anos, residentes no Brasil, que comprarem produtos Futi elegíveis dentro do período da promoção.",
  },
  {
    q: "Como eu recebo meus números da sorte?",
    a: "Depois de cadastrar sua nota fiscal na sua área, o sistema valida a compra e gera automaticamente seus números da sorte, respeitando o limite por CPF.",
  },
  {
    q: "Existe limite de números por pessoa?",
    a: "Sim — cada CPF pode acumular no máximo 200 números da sorte durante a promoção.",
  },
  {
    q: "Como funciona o sorteio?",
    a: "A apuração é feita com base nos resultados oficiais da Loteria Federal, conforme regra descrita no regulamento completo.",
  },
  {
    q: "Como vou saber se ganhei?",
    a: "Ganhadores são notificados por e-mail e podem conferir o resultado de cada sorteio diretamente na área do participante.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="bg-white px-6 py-24 md:px-10">
      <div className="mx-auto max-w-3xl">
        <span className="font-mono text-xs uppercase tracking-widest text-futi-green">
          Dúvidas frequentes
        </span>
        <h2 className="mt-3 font-display font-bold text-3xl sm:text-4xl text-ink text-balance">
          Perguntas que a gente já sabe que vem por aí.
        </h2>

        <div className="mt-9 divide-y divide-ink/10 border-t border-b border-ink/10">
          {faqs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q}>
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 py-5 text-left"
                >
                  <span className="font-display font-semibold text-ink">
                    {item.q}
                  </span>
                  <span
                    className={`shrink-0 font-display text-xl text-futi-green transition-transform ${
                      isOpen ? "rotate-45" : ""
                    }`}
                    aria-hidden="true"
                  >
                    +
                  </span>
                </button>
                {isOpen && (
                  <p className="pb-5 text-ink/70 leading-relaxed max-w-2xl">
                    {item.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
