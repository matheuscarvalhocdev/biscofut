import Image from "next/image";

export default function FiguresBanner() {
  return (
    <section className="relative isolate">
      <div className="relative h-[280px] sm:h-[360px] md:h-[440px] w-full overflow-hidden">
        <Image
          src="/images/futi-figures-field.png"
          alt="Bonequinhos colecionáveis Futi em um campo de futebol, cercados por torcida"
          fill
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-futi-navy-deep/90 via-futi-navy-deep/10 to-futi-navy-deep/40" />
      </div>
      <div className="absolute inset-0 flex items-end justify-center pb-10 sm:pb-14">
        <p className="font-display font-semibold text-xl sm:text-3xl text-white text-center text-balance px-6">
          Um time inteiro de colecionáveis pra chamar de seu.
        </p>
      </div>
    </section>
  );
}
