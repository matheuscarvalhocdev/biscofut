import Image from "next/image";

const products = [
  {
    id: "01",
    name: "Futi Collection",
    tier: "Nível P2",
    numbers: "3 números por unidade*",
    image: "/images/futi-collection-box.png",
    imgW: 180,
    imgH: 293,
    desc: "Blind box com bonequinho colecionável, biscoitos temáticos e uma bolinha de brinde.",
  },
  {
    id: "02",
    name: "Futi Arena",
    tier: "Nível P3",
    numbers: "5 números por unidade*",
    image: "/images/futi-arena-box.png",
    imgW: 300,
    imgH: 295,
    desc: "O set completo: 2 bonequinhos, 2 bolinhas, mini campo e kit de acessórios.",
  },
];

export default function EligibleProducts() {
  return (
    <section id="produtos" className="bg-biscoito px-6 pb-24 md:px-10">
      <div className="mx-auto max-w-6xl">
        <div className="max-w-xl">
          <span className="font-mono text-xs uppercase tracking-widest text-futi-green">
            Produtos participantes
          </span>
          <h2 className="mt-3 font-display font-bold text-3xl sm:text-4xl text-ink text-balance">
            Cada produto Futi vale números diferentes.
          </h2>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {products.map((p) => (
            <div
              key={p.id}
              className="group relative rounded-[1.75rem] border-2 border-dashed border-futi-green/25 bg-white/90 p-6 sm:p-8 overflow-hidden"
            >
              <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/50 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              <div className="relative flex items-center justify-between pb-5">
                <span className="font-mono text-xs uppercase tracking-widest text-futi-green">
                  Carta Nº {p.id}
                </span>
                <span className="rounded-full bg-futi-green/10 px-3 py-1 font-mono text-[0.65rem] uppercase tracking-widest text-futi-green">
                  {p.tier}
                </span>
              </div>

              <div className="relative flex items-center gap-6">
                <Image
                  src={p.image}
                  alt={`Embalagem do produto ${p.name}`}
                  width={p.imgW}
                  height={p.imgH}
                  className="h-28 w-auto drop-shadow-lg shrink-0"
                />
                <div>
                  <h3 className="font-display font-bold text-xl text-ink">
                    {p.name}
                  </h3>
                  <p className="mt-1.5 text-sm text-ink/70 leading-relaxed">
                    {p.desc}
                  </p>
                  <p className="mt-3 font-mono text-xs text-futi-green">
                    {p.numbers}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-5 text-xs text-ink/45">
          * Pesos por produto e por categoria (P1/P2/P3) são exemplos —
          valores finais a confirmar com o time de negócio antes do
          lançamento.
        </p>
      </div>
    </section>
  );
}
