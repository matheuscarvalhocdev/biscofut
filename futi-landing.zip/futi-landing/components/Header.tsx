export default function Header() {
  return (
    <header className="absolute top-0 left-0 right-0 z-30">
      <div className="mx-auto max-w-7xl px-6 md:px-10 py-6 flex items-center justify-between">
        <span className="font-display font-bold text-3xl text-white tracking-tight">
          futi
        </span>
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-white/85">
          <a href="#como-participar" className="hover:text-white transition-colors">
            Como participar
          </a>
          <a href="#produtos" className="hover:text-white transition-colors">
            Produtos
          </a>
          <a href="#premios" className="hover:text-white transition-colors">
            Prêmios
          </a>
          <a href="#regulamento" className="hover:text-white transition-colors">
            Regulamento
          </a>
          <a href="#faq" className="hover:text-white transition-colors">
            Dúvidas
          </a>
        </nav>
        <a
          href="#cadastro"
          className="rounded-full bg-futi-yellow px-5 py-2.5 font-display font-semibold text-sm text-futi-navy-deep shadow-[0_4px_0_0_#B38400] transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-[0_2px_0_0_#B38400]"
        >
          Participar
        </a>
      </div>
    </header>
  );
}
