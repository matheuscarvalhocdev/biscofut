const steps = [
  {
    n: "1",
    title: "Compre produtos Futi",
    text: "Futi Collection ou Futi Arena, em qualquer loja participante. Guarde sua nota fiscal — ela é o seu bilhete de entrada.",
  },
  {
    n: "2",
    title: "Cadastre sua nota fiscal",
    text: "Crie sua conta, informe a chave de acesso da nota (ou tire uma foto do QR code) e aguarde a validação.",
  },
  {
    n: "3",
    title: "Receba seus números e concorra",
    text: "Cada produto elegível gera números da sorte. Acompanhe tudo na sua área e confira os resultados dos sorteios pela Loteria Federal.",
  },
];

export default function HowItWorks() {
  return (
    <section id="como-participar" className="bg-biscoito px-6 py-24 md:px-10">
      <div className="mx-auto max-w-6xl">
        <div className="max-w-xl">
          <span className="font-mono text-xs uppercase tracking-widest text-futi-green">
            Como participar
          </span>
          <h2 className="mt-3 font-display font-bold text-3xl sm:text-4xl text-ink text-balance">
            Simples assim: comprou, cadastrou, já tá concorrendo.
          </h2>
        </div>

        <div className="mt-14 grid gap-8 md:grid-cols-3 md:gap-6">
          {steps.map((step, i) => (
            <div key={step.n} className="relative">
              {i < steps.length - 1 && (
                <div
                  className="hidden md:block absolute top-7 left-[calc(100%-0.5rem)] w-[calc(100%-2.5rem)] border-t-2 border-dashed border-futi-green/30"
                  aria-hidden="true"
                />
              )}
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-futi-green text-white font-display font-bold text-xl">
                {step.n}
              </div>
              <h3 className="mt-5 font-display font-semibold text-xl text-ink">
                {step.title}
              </h3>
              <p className="mt-2 text-ink/70 leading-relaxed">{step.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
