const prizes = [
  {
    n: "01",
    title: "Prêmio principal",
    desc: "[Descrição do prêmio principal — a definir pelo time de negócio]",
  },
  {
    n: "02",
    title: "Prêmios semanais",
    desc: "[Ex.: vales-compra ou kits Futi — a definir]",
  },
  {
    n: "03",
    title: "Prêmios instantâneos",
    desc: "[A definir — depende da mecânica de apuração escolhida]",
  },
];

export default function Prizes() {
  return (
    <section id="premios" className="bg-futi-navy-deep px-6 py-24 md:px-10">
      <div className="mx-auto max-w-6xl">
        <div className="max-w-xl">
          <span className="font-mono text-xs uppercase tracking-widest text-futi-yellow">
            Prêmios
          </span>
          <h2 className="mt-3 font-display font-bold text-3xl sm:text-4xl text-white text-balance">
            O que está em jogo.
          </h2>
        </div>

        <div className="mt-4 inline-flex items-start gap-2 rounded-xl border border-dashed border-white/25 bg-white/5 px-4 py-3">
          <span aria-hidden="true">🚧</span>
          <p className="text-xs text-white/60 max-w-md">
            Conteúdo de exemplo. Os prêmios reais serão definidos pelo time de
            negócio e publicados no regulamento oficial antes do lançamento.
          </p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {prizes.map((prize) => (
            <div
              key={prize.n}
              className="rounded-[1.75rem] border-2 border-dashed border-gold-trophy/30 bg-white/5 p-7"
            >
              <span className="font-mono text-xs uppercase tracking-widest text-gold-trophy">
                Carta Nº {prize.n}
              </span>
              <h3 className="mt-4 font-display font-bold text-xl text-white">
                {prize.title}
              </h3>
              <p className="mt-2 text-sm text-white/60 italic leading-relaxed">
                {prize.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
