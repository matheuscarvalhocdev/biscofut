export default function Footer() {
  return (
    <footer className="bg-futi-navy-deep border-t border-white/10 px-6 py-12 md:px-10">
      <div className="mx-auto max-w-7xl flex flex-col md:flex-row items-center md:items-start justify-between gap-8">
        <div>
          <span className="font-display font-bold text-2xl text-white">
            futi
          </span>
          <p className="mt-2 text-xs text-white/45 max-w-xs text-center md:text-left">
            Uma promoção Biscoitê × Neymar Jr.
          </p>
        </div>

        <nav className="flex flex-wrap justify-center gap-x-8 gap-y-2 text-sm text-white/55">
          <a href="#como-participar" className="hover:text-white transition-colors">
            Como participar
          </a>
          <a href="#premios" className="hover:text-white transition-colors">
            Prêmios
          </a>
          <a href="#regulamento" className="hover:text-white transition-colors">
            Regulamento
          </a>
          <a href="#faq" className="hover:text-white transition-colors">
            Dúvidas
          </a>
        </nav>
      </div>

      <div className="mx-auto max-w-7xl mt-10 pt-6 border-t border-white/10 text-[0.7rem] text-white/35 text-center sm:text-left space-y-2">
        <p>
          Promoção comercial autorizada pela SPA/Ministério da Fazenda —
          Certificado de Autorização Nº <strong>aguardando emissão</strong>.
          Participação sujeita ao regulamento oficial.
        </p>
        <p>
          Imagens meramente ilustrativas. Produtos, prêmios e datas sujeitos
          a confirmação.
        </p>
        <p>© {new Date().getFullYear()} Biscoitê Alimentos S.A.</p>
      </div>
    </footer>
  );
}
