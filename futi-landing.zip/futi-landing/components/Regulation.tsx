const bullets = [
  "Podem participar pessoas físicas maiores de 18 anos, residentes no Brasil.",
  "A participação depende da compra de produtos Futi elegíveis e do cadastro da nota fiscal correspondente.",
  "Cada CPF pode acumular no máximo 200 números da sorte durante a promoção.",
  "A apuração dos ganhadores é feita com base nos resultados da Loteria Federal.",
  "Vigência: [DD/MM/AAAA] a [DD/MM/AAAA] — datas a confirmar.",
];

export default function Regulation() {
  return (
    <section id="regulamento" className="bg-biscoito px-6 py-24 md:px-10">
      <div className="mx-auto max-w-4xl">
        <span className="font-mono text-xs uppercase tracking-widest text-futi-green">
          Regulamento
        </span>
        <h2 className="mt-3 font-display font-bold text-3xl sm:text-4xl text-ink text-balance">
          O resumo — e onde ler tudo, sem pressa.
        </h2>

        <ul className="mt-8 space-y-3">
          {bullets.map((b) => (
            <li key={b} className="flex items-start gap-3 text-ink/75 leading-relaxed">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-futi-green" />
              {b}
            </li>
          ))}
        </ul>

        <div className="mt-9 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <button
            type="button"
            disabled
            title="Disponível assim que o regulamento for aprovado e o CA for emitido"
            className="cursor-not-allowed rounded-full border border-ink/20 bg-white px-6 py-3 font-display font-semibold text-sm text-ink/40"
          >
            Baixar regulamento completo (PDF)
          </button>
          <span className="text-xs text-ink/45 max-w-sm">
            Disponível assim que o regulamento for aprovado e o Certificado
            de Autorização (CA) for emitido pela SPA/MF.
          </span>
        </div>

        <p className="mt-8 rounded-xl border border-dashed border-ink/15 bg-white/60 px-4 py-3 text-xs text-ink/50">
          Certificado de Autorização SPA/MF Nº <strong>aguardando emissão</strong>.
          Promoção comercial em conformidade com a Lei 5.768/71, Decreto
          70.951/72 e Lei 13.756/2018.
        </p>
      </div>
    </section>
  );
}
