import Image from "next/image";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-futi-navy-deep text-white">
      <div className="absolute inset-0 bg-grain [background-size:18px_18px] opacity-[0.15] pointer-events-none" />
      <div className="absolute -top-32 right-0 h-[520px] w-[520px] rounded-full bg-gold-trophy/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-futi-green/30 blur-[100px] pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-6 md:px-10 pt-32 pb-20 md:pt-40 md:pb-28 grid md:grid-cols-[1.15fr_0.85fr] gap-14 items-center">
        <div className="animate-floatUp">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-4 py-1.5 text-xs font-mono uppercase tracking-widest text-futi-yellow">
            Promoção Futi · Biscoitê × Neymar Jr.
          </span>

          <h1 className="mt-6 font-display font-bold text-balance text-4xl leading-[1.08] sm:text-5xl md:text-[3.2rem] md:leading-[1.08]">
            Sua nota fiscal
            <br />
            pode valer um baita prêmio.
          </h1>

          <p className="mt-6 max-w-xl text-lg text-white/75">
            O Neymar Jr. sempre sonhou em ter uma fábrica de biscoitos. Agora
            que ele topou jogar em time com a Biscoitê, chegou a hora de
            dividir essa com você: compre produtos{" "}
            <span className="font-display text-futi-yellow">futi</span>,
            cadastre sua nota fiscal e concorra.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#cadastro"
              className="rounded-full bg-futi-yellow px-6 py-3 font-display font-semibold text-futi-navy-deep text-sm shadow-[0_8px_0_0_#B38400] transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-[0_4px_0_0_#B38400]"
            >
              Quero participar
            </a>
            <a
              href="#premios"
              className="rounded-full border border-white/30 px-6 py-3 font-display font-semibold text-sm text-white/90 transition-colors hover:border-white/60 hover:text-white"
            >
              Ver os prêmios
            </a>
          </div>

          <p className="mt-6 text-xs text-white/40 max-w-md">
            Promoção comercial sujeita a autorização da SPA/Ministério da
            Fazenda. Consulte o regulamento antes de participar.
          </p>
        </div>

        <div className="relative mx-auto w-full max-w-[280px] md:max-w-none">
          <div className="absolute -inset-3 rounded-[2rem] bg-gradient-to-br from-futi-yellow/40 via-transparent to-futi-green/30 blur-xl" />
          <div className="relative rounded-[1.75rem] border-2 border-dashed border-white/30 bg-white/[0.04] p-3 backdrop-blur-sm">
            <div className="flex items-center justify-between px-2 pb-2">
              <span className="font-mono text-[0.65rem] uppercase tracking-widest text-white/60">
                Carta Nº 00
              </span>
              <span className="font-mono text-[0.65rem] uppercase tracking-widest text-futi-yellow">
                A origem
              </span>
            </div>
            <div className="relative overflow-hidden rounded-[1.25rem] bg-pitch">
              <Image
                src="/images/neymar-hero.png"
                alt="Neymar Jr. em campo, com o uniforme da seleção brasileira"
                width={243}
                height={300}
                className="h-full w-full object-cover"
                priority
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-futi-navy-deep/80 via-transparent to-transparent" />
            </div>
            <p className="px-2 pt-3 pb-1 text-xs leading-relaxed text-white/55">
              Imagem meramente ilustrativa da campanha Futi.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
