"use client";

import { FormEvent, useState } from "react";
import { formatCPF, isValidCPF } from "@/lib/cpf";
import { PROMO_STATUS, type PromoStatus } from "@/lib/promoStatus";

type FormErrors = Partial<Record<"nome" | "cpf" | "nascimento" | "email" | "aceite", string>>;

export default function RegistrationArea() {
  // Alternância só para demonstração/revisão de design — em produção o
  // status vem do backend (ver lib/promoStatus.ts) e não é escolhido aqui.
  const [previewStatus, setPreviewStatus] = useState<PromoStatus>(PROMO_STATUS);

  const [tab, setTab] = useState<"criar" | "entrar">("criar");
  const [values, setValues] = useState({
    nome: "",
    cpf: "",
    nascimento: "",
    email: "",
    celular: "",
    aceite: false,
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [createdAccount, setCreatedAccount] = useState(false);

  const [notifyEmail, setNotifyEmail] = useState("");
  const [notifySent, setNotifySent] = useState(false);
  const [notifyError, setNotifyError] = useState("");

  function handleCreateAccount(e: FormEvent) {
    e.preventDefault();
    const next: FormErrors = {};
    if (values.nome.trim().length < 3) next.nome = "Informe seu nome completo.";
    if (!isValidCPF(values.cpf)) next.cpf = "CPF inválido.";
    if (!values.nascimento) next.nascimento = "Informe sua data de nascimento.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email))
      next.email = "Digite um e-mail válido.";
    if (!values.aceite) next.aceite = "É preciso aceitar o regulamento.";

    setErrors(next);
    if (Object.keys(next).length === 0) {
      // Demonstração de front-end: nenhuma informação é enviada a um
      // servidor. A integração real acontece na próxima fase do projeto.
      setCreatedAccount(true);
    }
  }

  function handleNotify(e: FormEvent) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(notifyEmail)) {
      setNotifyError("Digite um e-mail válido.");
      return;
    }
    setNotifyError("");
    setNotifySent(true);
  }

  return (
    <section id="cadastro" className="bg-white px-6 py-24 md:px-10">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col items-center text-center">
          <span className="font-mono text-xs uppercase tracking-widest text-futi-green">
            Participe
          </span>
          <h2 className="mt-3 font-display font-bold text-3xl sm:text-4xl text-ink text-balance">
            Crie sua conta e comece a concorrer.
          </h2>

          {/* Alternância de demonstração — remover antes de publicar */}
          <div className="mt-6 inline-flex items-center gap-1 rounded-full border border-ink/10 bg-biscoito p-1 text-xs font-mono">
            <span className="px-3 text-ink/40 uppercase tracking-widest hidden sm:inline">
              Prévia:
            </span>
            <button
              type="button"
              onClick={() => setPreviewStatus("PRE_LAUNCH")}
              className={`rounded-full px-3 py-1.5 transition-colors ${
                previewStatus === "PRE_LAUNCH"
                  ? "bg-futi-navy-deep text-white"
                  : "text-ink/50 hover:text-ink"
              }`}
            >
              Antes do CA
            </button>
            <button
              type="button"
              onClick={() => setPreviewStatus("ACTIVE")}
              className={`rounded-full px-3 py-1.5 transition-colors ${
                previewStatus === "ACTIVE"
                  ? "bg-futi-green text-white"
                  : "text-ink/50 hover:text-ink"
              }`}
            >
              Depois do CA
            </button>
          </div>
        </div>

        {previewStatus === "PRE_LAUNCH" ? (
          <div className="mt-12 mx-auto max-w-xl rounded-[2rem] border-2 border-dashed border-ink/15 bg-biscoito p-8 sm:p-12 text-center">
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border-2 border-dashed border-futi-green/40 font-display text-2xl text-futi-green">
              🔒
            </div>
            <h3 className="font-display font-bold text-2xl text-ink">
              O cadastro abre assim que o CA for emitido
            </h3>
            <p className="mt-3 text-ink/65 max-w-md mx-auto">
              A promoção Futi depende da autorização da SPA/Ministério da
              Fazenda. Por enquanto, você já pode deixar seu e-mail pra ser
              avisado no instante em que o cadastro for liberado.
            </p>

            {notifySent ? (
              <p className="mt-6 font-display text-futi-green">
                Prontinho — é só aguardar. 🎉
              </p>
            ) : (
              <form
                onSubmit={handleNotify}
                className="mt-6 flex flex-col sm:flex-row gap-3 max-w-sm mx-auto"
                noValidate
              >
                <label htmlFor="notify-email" className="sr-only">
                  Seu e-mail
                </label>
                <input
                  id="notify-email"
                  type="email"
                  value={notifyEmail}
                  onChange={(e) => setNotifyEmail(e.target.value)}
                  placeholder="seuemail@exemplo.com"
                  className="w-full rounded-full border border-ink/15 bg-white px-5 py-3 text-sm text-ink placeholder:text-ink/35 outline-none focus-visible:border-futi-green"
                />
                <button
                  type="submit"
                  className="shrink-0 rounded-full bg-futi-green px-6 py-3 font-display font-semibold text-sm text-white transition-transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  Avisar
                </button>
              </form>
            )}
            {notifyError && (
              <p role="alert" className="mt-3 text-sm text-red-500">
                {notifyError}
              </p>
            )}
          </div>
        ) : (
          <div className="mt-12 grid gap-8 lg:grid-cols-[1.1fr_0.9fr] items-start">
            {/* Formulário */}
            <div className="rounded-[2rem] border-2 border-dashed border-futi-green/25 bg-biscoito p-6 sm:p-10">
              <div className="inline-flex rounded-full border border-ink/10 bg-white p-1 text-sm">
                <button
                  type="button"
                  onClick={() => setTab("criar")}
                  className={`rounded-full px-4 py-2 font-display font-semibold transition-colors ${
                    tab === "criar"
                      ? "bg-futi-green text-white"
                      : "text-ink/50 hover:text-ink"
                  }`}
                >
                  Criar conta
                </button>
                <button
                  type="button"
                  onClick={() => setTab("entrar")}
                  className={`rounded-full px-4 py-2 font-display font-semibold transition-colors ${
                    tab === "entrar"
                      ? "bg-futi-green text-white"
                      : "text-ink/50 hover:text-ink"
                  }`}
                >
                  Já tenho conta
                </button>
              </div>

              {tab === "criar" ? (
                createdAccount ? (
                  <div className="mt-8 text-center py-10">
                    <p className="font-display text-2xl text-futi-green">
                      Conta criada! 🎉
                    </p>
                    <p className="mt-2 text-sm text-ink/60 max-w-sm mx-auto">
                      (Demonstração de front-end — nenhum dado foi enviado a
                      um servidor. A integração com o backend entra na
                      próxima fase.)
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleCreateAccount} className="mt-7 space-y-4" noValidate>
                    <Field label="Nome completo" error={errors.nome}>
                      <input
                        type="text"
                        value={values.nome}
                        onChange={(e) => setValues({ ...values, nome: e.target.value })}
                        className={inputClass(!!errors.nome)}
                        placeholder="Como está no seu documento"
                      />
                    </Field>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <Field label="CPF" error={errors.cpf}>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={values.cpf}
                          onChange={(e) =>
                            setValues({ ...values, cpf: formatCPF(e.target.value) })
                          }
                          className={inputClass(!!errors.cpf)}
                          placeholder="000.000.000-00"
                          maxLength={14}
                        />
                      </Field>
                      <Field label="Data de nascimento" error={errors.nascimento}>
                        <input
                          type="date"
                          value={values.nascimento}
                          onChange={(e) =>
                            setValues({ ...values, nascimento: e.target.value })
                          }
                          className={inputClass(!!errors.nascimento)}
                        />
                      </Field>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <Field label="E-mail" error={errors.email}>
                        <input
                          type="email"
                          value={values.email}
                          onChange={(e) => setValues({ ...values, email: e.target.value })}
                          className={inputClass(!!errors.email)}
                          placeholder="seuemail@exemplo.com"
                        />
                      </Field>
                      <Field label="Celular (opcional)">
                        <input
                          type="tel"
                          value={values.celular}
                          onChange={(e) =>
                            setValues({ ...values, celular: e.target.value })
                          }
                          className={inputClass(false)}
                          placeholder="(00) 00000-0000"
                        />
                      </Field>
                    </div>

                    <label className="flex items-start gap-2.5 pt-1 text-sm text-ink/70">
                      <input
                        type="checkbox"
                        checked={values.aceite}
                        onChange={(e) =>
                          setValues({ ...values, aceite: e.target.checked })
                        }
                        className="mt-0.5 h-4 w-4 rounded border-ink/25 accent-futi-green"
                      />
                      Li e aceito o{" "}
                      <a href="#regulamento" className="text-futi-green underline underline-offset-2">
                        regulamento oficial
                      </a>{" "}
                      da promoção.
                    </label>
                    {errors.aceite && (
                      <p className="text-sm text-red-500">{errors.aceite}</p>
                    )}

                    <button
                      type="submit"
                      className="w-full rounded-full bg-futi-yellow px-6 py-3.5 font-display font-semibold text-futi-navy-deep shadow-[0_6px_0_0_#B38400] transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-[0_3px_0_0_#B38400]"
                    >
                      Criar minha conta
                    </button>
                  </form>
                )
              ) : (
                <form className="mt-7 space-y-4" onSubmit={(e) => e.preventDefault()} noValidate>
                  <Field label="E-mail">
                    <input type="email" className={inputClass(false)} placeholder="seuemail@exemplo.com" />
                  </Field>
                  <Field label="Senha">
                    <input type="password" className={inputClass(false)} placeholder="••••••••" />
                  </Field>
                  <button
                    type="submit"
                    className="w-full rounded-full bg-futi-yellow px-6 py-3.5 font-display font-semibold text-futi-navy-deep shadow-[0_6px_0_0_#B38400] transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-[0_3px_0_0_#B38400]"
                  >
                    Entrar
                  </button>
                  <p className="text-center text-xs text-ink/40">
                    (Tela de demonstração — login real chega com o backend.)
                  </p>
                </form>
              )}
            </div>

            {/* Prévia da área do participante */}
            <div className="rounded-[2rem] border-2 border-dashed border-futi-navy/20 bg-futi-navy-deep p-6 sm:p-8 text-white">
              <span className="font-mono text-xs uppercase tracking-widest text-white/50">
                Prévia ilustrativa
              </span>
              <h3 className="mt-2 font-display font-bold text-xl">
                Assim fica sua área depois de cadastrar
              </h3>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-white/5 p-4">
                  <p className="text-2xl font-display font-bold text-futi-yellow">128</p>
                  <p className="text-xs text-white/55 mt-1">números da sorte</p>
                </div>
                <div className="rounded-2xl bg-white/5 p-4">
                  <p className="text-2xl font-display font-bold text-futi-yellow">2</p>
                  <p className="text-xs text-white/55 mt-1">notas cadastradas</p>
                </div>
              </div>

              <div className="mt-4 rounded-2xl bg-white/5 p-4">
                <p className="text-xs text-white/55">Saldo até o limite por CPF</p>
                <div className="mt-2 h-2 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full w-[64%] rounded-full bg-futi-yellow" />
                </div>
                <p className="mt-1.5 text-xs text-white/40">128 de 200 números</p>
              </div>

              <p className="mt-5 text-xs text-white/35">
                Valores meramente ilustrativos, para exemplificar o layout da
                área logada.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function inputClass(hasError: boolean) {
  return `w-full rounded-xl border ${
    hasError ? "border-red-400" : "border-ink/15"
  } bg-white px-4 py-2.5 text-sm text-ink placeholder:text-ink/35 outline-none focus-visible:border-futi-green`;
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-ink/60">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-red-500">{error}</span>}
    </label>
  );
}
