import Header from "@/components/Header";
import Hero from "@/components/Hero";
import HowItWorks from "@/components/HowItWorks";
import EligibleProducts from "@/components/EligibleProducts";
import FiguresBanner from "@/components/FiguresBanner";
import Prizes from "@/components/Prizes";
import RegistrationArea from "@/components/RegistrationArea";
import Regulation from "@/components/Regulation";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <HowItWorks />
      <EligibleProducts />
      <FiguresBanner />
      <Prizes />
      <RegistrationArea />
      <Regulation />
      <FAQ />
      <Footer />
    </main>
  );
}
